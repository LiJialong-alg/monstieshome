import { PrismaClient } from "@prisma/client"
import bcrypt from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  const password = await bcrypt.hash("babymomo1234567rpaarrc", 12)

  await prisma.user.upsert({
    where: { username: "monstieshome" },
    update: { password, role: "superadmin" },
    create: { username: "monstieshome", password, role: "superadmin" },
  })

  await prisma.user.deleteMany({ where: { username: "admin" } })
  console.log("管理账号已写入")
}

main().finally(() => prisma.$disconnect())
