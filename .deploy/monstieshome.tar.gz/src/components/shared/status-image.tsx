"use client"

import type { ImgHTMLAttributes } from "react"
import { useState } from "react"

export function StatusImage({ className = "", alt = "图片", onLoad, onError, ...props }: ImgHTMLAttributes<HTMLImageElement>) {
  const [state, setState] = useState<"loading" | "loaded" | "error">("loading")
  return (
    <div className="relative h-full w-full">
      {state !== "loaded" && <div className="absolute inset-0 z-10 flex items-center justify-center bg-slate-100/90 text-xs text-slate-400">{state === "loading" ? "图片加载中…" : "图片加载失败"}</div>}
      <img {...props} alt={alt} className={`${className} ${state === "error" ? "opacity-0" : "opacity-100"}`} onLoad={(event) => { setState("loaded"); onLoad?.(event) }} onError={(event) => { setState("error"); onError?.(event) }} />
    </div>
  )
}
